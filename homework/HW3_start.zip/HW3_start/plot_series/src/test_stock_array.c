// Test File Created with the Help of LLM Assistance
// Claude Sonnet 4.6 
/*
 * test_stock_array.c
 *
 * Minimal tests for your stock_array.h implementation.
 * Each test prints PASS or FAIL with a short explanation.
 *
 * Compile:
 *   gcc -Wall -Wextra -o test_stock_array test_stock_array.c
 *
 * Run:
 *   ./test_stock_array
 *
 * All tests should print PASS before you submit.
 * If a test prints FAIL, re-read the corresponding function's
 * comment block in stock_array.h and check your implementation.
 */

#include "stock_array.h"

/* =========================================================================
 * SMALL TEST HELPERS
 * ========================================================================= */

static int tests_run    = 0;
static int tests_passed = 0;

/* Call this at the end to print a summary */
static void print_summary(void)
{
    printf("\n-----------------------------------------\n");
    printf("  %d / %d tests passed\n", tests_passed, tests_run);
    printf("-----------------------------------------\n\n");
}

/*
 * CHECK macro
 * -----------
 * Evaluates condition. Prints PASS or FAIL with the test name.
 * Use this for every individual assertion.
 *
 * Example:
 *   CHECK("size starts at zero", sa.size == 0);
 */
#define CHECK(name, condition)                                          \
    do {                                                                \
        tests_run++;                                                    \
        if (condition) {                                                \
            printf("  PASS  %s\n", name);                              \
            tests_passed++;                                             \
        } else {                                                        \
            printf("  FAIL  %s  (line %d)\n", name, __LINE__);        \
        }                                                               \
    } while (0)

/* Tolerance for floating point comparisons */
#define EPSILON 0.0001

static int doubles_equal(double a, double b)
{
    double diff = a - b;
    if (diff < 0) diff = -diff;
    return diff < EPSILON;
}


/* =========================================================================
 * TEST: sa_create and sa_destroy
 * =========================================================================
 *
 * Checks that a newly created StockArray has the right initial state
 * and that destroy cleans up without crashing.
 */
static void test_create_destroy(void)
{
    printf("\n[ sa_create / sa_destroy ]\n");

    StockArray sa = sa_create(INITIAL_CAPACITY);

    CHECK("size starts at 0",               sa.size     == 0);
    CHECK("capacity matches request",        sa.capacity == INITIAL_CAPACITY);
    CHECK("records pointer is not NULL",     sa.records  != NULL);

    sa_destroy(&sa);

    CHECK("records is NULL after destroy",   sa.records  == NULL);
    CHECK("size is 0 after destroy",         sa.size     == 0);
    CHECK("capacity is 0 after destroy",     sa.capacity == 0);
}


/* =========================================================================
 * TEST: sa_append and sa_get
 * =========================================================================
 *
 * Appends a handful of known records and checks that sa_get returns them
 * correctly. Also verifies that size grows with each append.
 */
static void test_append_and_get(void)
{
    printf("\n[ sa_append / sa_get ]\n");

    StockArray sa = sa_create(2);

    /* Build three known records manually */
    DayRecord r0 = {"2024-01-01", 155.50, 149.20, 152.35};
    DayRecord r1 = {"2024-01-02", 160.10, 153.80, 156.95};
    DayRecord r2 = {"2024-01-03", 158.75, 151.40, 155.07};

    sa_append(&sa, r0);
    CHECK("size is 1 after first append",    sa.size == 1);

    sa_append(&sa, r1);
    CHECK("size is 2 after second append",   sa.size == 2);

    /* Third append must trigger a resize since capacity started at 2 */
    sa_append(&sa, r2);
    CHECK("size is 3 after third append",    sa.size == 3);
    CHECK("capacity grew on resize",         sa.capacity >= 3);

    /* Verify data survived the resize */
    DayRecord got0 = sa_get(&sa, 0);
    DayRecord got1 = sa_get(&sa, 1);
    DayRecord got2 = sa_get(&sa, 2);

    CHECK("get(0) date correct",   strcmp(got0.date, "2024-01-01") == 0);
    CHECK("get(0) high correct",   doubles_equal(got0.high, 155.50));
    CHECK("get(0) low correct",    doubles_equal(got0.low,  149.20));
    CHECK("get(0) avg correct",    doubles_equal(got0.avg,  152.35));

    CHECK("get(1) date correct",   strcmp(got1.date, "2024-01-02") == 0);
    CHECK("get(1) high correct",   doubles_equal(got1.high, 160.10));

    CHECK("get(2) date correct",   strcmp(got2.date, "2024-01-03") == 0);
    CHECK("get(2) low correct",    doubles_equal(got2.low,  151.40));

    sa_destroy(&sa);
}


/* =========================================================================
 * TEST: sa_load_data
 * =========================================================================
 *
 *
 * Day 0: 100.0, 105.0, 102.0  -> high=105.0  low=100.0  avg=102.333...
 * Day 1: 200.0, 195.0         -> high=200.0  low=195.0  avg=197.5
 * Day 2: 50.0, 55.0, 60.0, 45.0 -> high=60.0  low=45.0  avg=52.5
 */
static void test_load_data(void)
{
    printf("\n[ sa_load_file ]\n");

    /* Write a temp file in the two-line-per-day format */
    const char* filename = "test_temp.txt";
    FILE* f = fopen(filename, "w");
    if (!f) {
        printf("  FAIL  could not create temp file for testing\n");
        return;
    }
    fprintf(f, "2024-03-01\n");
    fprintf(f, "100.0 105.0 98.0 102.0\n");   // high=105, low=98,  avg=101.25
    fprintf(f, "2024-03-02\n");
    fprintf(f, "196.0 200.0 195.0 199.0\n");  // high=200, low=195, avg=197.5
    fprintf(f, "2024-03-03\n");
    fprintf(f, "50.0 60.0 45.0 55.0\n");      // high=60,  low=45,  avg=52.5
    fclose(f);

    StockArray sa = sa_create(INITIAL_CAPACITY);
    int ok = sa_load_data(&sa, filename);

    CHECK("load_file returns 1 on success",  ok == 1);
    CHECK("three records loaded",            sa.size == 3);

    if (sa.size >= 1) {
        DayRecord d0 = sa_get(&sa, 0);
        CHECK("day 0 date",  strcmp(d0.date, "2024-03-01") == 0);
        CHECK("day 0 high",  doubles_equal(d0.high, 105.0));
        CHECK("day 0 low",   doubles_equal(d0.low,  98.0));
        CHECK("day 0 avg",   doubles_equal(d0.avg,  101.25));
    }

    if (sa.size >= 2) {
        DayRecord d1 = sa_get(&sa, 1);
        CHECK("day 1 date",  strcmp(d1.date, "2024-03-02") == 0);
        CHECK("day 1 high",  doubles_equal(d1.high, 200.0));
        CHECK("day 1 low",   doubles_equal(d1.low,  195.0));
        CHECK("day 1 avg",   doubles_equal(d1.avg,  197.5));
    }

    if (sa.size >= 3) {
        DayRecord d2 = sa_get(&sa, 2);
        CHECK("day 2 date",  strcmp(d2.date, "2024-03-03") == 0);
        CHECK("day 2 high",  doubles_equal(d2.high, 60.0));
        CHECK("day 2 low",   doubles_equal(d2.low,  45.0));
        CHECK("day 2 avg",   doubles_equal(d2.avg,  52.5));
    }

    /* Bad filename still returns 0 */
    StockArray sa2 = sa_create(INITIAL_CAPACITY);
    int bad = sa_load_data(&sa2, "this_file_does_not_exist.txt");
    CHECK("load_file returns 0 on bad filename", bad == 0);

    sa_destroy(&sa);
    sa_destroy(&sa2);
    remove(filename);
}

/* =========================================================================
 * TEST: sa_overall_high / sa_overall_low / sa_overall_avg
 * =========================================================================
 *
 * Uses three hand-crafted records where the correct answers are easy
 * to verify by inspection.
 *
 *   Record 0: high=200  low=100  avg=150
 *   Record 1: high=300  low= 50  avg=175
 *   Record 2: high=250  low=150  avg=200
 *
 *   overall_high = 300
 *   overall_low  =  50
 *   overall_avg  = (150 + 175 + 200) / 3 = 175.0
 */
static void test_analysis(void)
{
    printf("\n[ sa_overall_high / sa_overall_low / sa_overall_avg ]\n");

    StockArray sa = sa_create(INITIAL_CAPACITY);

    DayRecord r0 = {"2024-01-01", 200.0, 100.0, 150.0};
    DayRecord r1 = {"2024-01-02", 300.0,  50.0, 175.0};
    DayRecord r2 = {"2024-01-03", 250.0, 150.0, 200.0};

    sa_append(&sa, r0);
    sa_append(&sa, r1);
    sa_append(&sa, r2);

    CHECK("overall_high is 300", doubles_equal(sa_overall_high(&sa), 300.0));
    CHECK("overall_low  is  50", doubles_equal(sa_overall_low(&sa),   50.0));
    CHECK("overall_avg  is 175", doubles_equal(sa_overall_avg(&sa),  175.0));

    sa_destroy(&sa);
}


/* =========================================================================
 * TEST: sa_extract_highs / sa_extract_lows / sa_extract_avgs
 * =========================================================================
 *
 * Uses the same three records as above. Checks that the returned arrays
 * contain the right values in order and that they are independent heap
 * allocations (not pointers into the StockArray itself).
 */
static void test_extract(void)
{
    printf("\n[ sa_extract_highs / sa_extract_lows / sa_extract_avgs ]\n");

    StockArray sa = sa_create(INITIAL_CAPACITY);

    DayRecord r0 = {"2024-01-01", 200.0, 100.0, 150.0};
    DayRecord r1 = {"2024-01-02", 300.0,  50.0, 175.0};
    DayRecord r2 = {"2024-01-03", 250.0, 150.0, 200.0};

    sa_append(&sa, r0);
    sa_append(&sa, r1);
    sa_append(&sa, r2);

    double* highs = sa_extract_highs(&sa);
    double* lows  = sa_extract_lows(&sa);
    double* avgs  = sa_extract_avgs(&sa);

    CHECK("extract_highs not NULL",        highs != NULL);
    CHECK("extract_lows  not NULL",        lows  != NULL);
    CHECK("extract_avgs  not NULL",        avgs  != NULL);

    /* Verify extract arrays are separate allocations from records */
    CHECK("highs not aliasing records",    (void*)highs != (void*)sa.records);
    CHECK("lows  not aliasing records",    (void*)lows  != (void*)sa.records);
    CHECK("avgs  not aliasing records",    (void*)avgs  != (void*)sa.records);

    if (highs) {
        CHECK("highs[0] == 200", doubles_equal(highs[0], 200.0));
        CHECK("highs[1] == 300", doubles_equal(highs[1], 300.0));
        CHECK("highs[2] == 250", doubles_equal(highs[2], 250.0));
    }

    if (lows) {
        CHECK("lows[0] == 100", doubles_equal(lows[0], 100.0));
        CHECK("lows[1] ==  50", doubles_equal(lows[1],  50.0));
        CHECK("lows[2] == 150", doubles_equal(lows[2], 150.0));
    }

    if (avgs) {
        CHECK("avgs[0] == 150", doubles_equal(avgs[0], 150.0));
        CHECK("avgs[1] == 175", doubles_equal(avgs[1], 175.0));
        CHECK("avgs[2] == 200", doubles_equal(avgs[2], 200.0));
    }

    free(highs);
    free(lows);
    free(avgs);
    sa_destroy(&sa);
}


/* =========================================================================
 * TEST: plot_series smoke test
 * =========================================================================
 *
 * Just verifies that plot_series runs without crashing on a small input.
 * Visual output is printed so you can eyeball that it looks reasonable.
 */
static void test_plot_smoke(void)
{
    printf("\n[ plot_series smoke test ]\n");
    printf("  (visual check - make sure the chart below looks reasonable)\n");

    double values[10] = {10.0, 20.0, 15.0, 30.0, 25.0,
                         35.0, 28.0, 40.0, 33.0, 45.0};

    plot_series(values, 10, "Smoke Test - rising trend");

    /* If we got here without crashing, count it as a pass */
    CHECK("plot_series did not crash", 1);
}


/* =========================================================================
 * MAIN
 * ========================================================================= */

int main(void)
{
    printf("=========================================\n");
    printf("  stock_array.h - student test suite\n");
    printf("=========================================\n");

    test_create_destroy();
    test_append_and_get();
    test_load_data();
    test_analysis();
    test_extract();
    test_plot_smoke();

    print_summary();

    return (tests_passed == tests_run) ? 0 : 1;
}
