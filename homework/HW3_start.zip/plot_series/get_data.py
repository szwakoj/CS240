"""
generate_stock_data.py

Downloads one year of daily stock data for several tickers and writes
each one to a plain text file formatted for the stock array assignment.

Each output file has one line per trading day:
    YYYY-MM-DD open1 open2 ... close

Install dependency:
    pip install yfinance

Run:
    python generate_stock_data.py

Output files will appear in ./data/
"""

import os
import yfinance as yf

# --- Configure these as you like ---

TICKERS = [
    "AAPL",   # Steady large cap
    "NVDA",   # Dramatic 2024 run-up
    "TSLA",   # High volatility
    "JNJ",    # Boring stable defensive
    "GME",    # Meme stock, fun spikes
]

START = "2024-01-01"
END   = "2024-12-31"
OUTDIR = "data"

# ------------------------------------

os.makedirs(OUTDIR, exist_ok=True)

for ticker in TICKERS:
    print(f"Downloading {ticker}...")
    df = yf.download(ticker, start=START, end=END, auto_adjust=True)
    df.columns = df.columns.get_level_values(0)

    if df.empty:
        print(f"  WARNING: no data returned for {ticker}, skipping")
        continue

    outpath = os.path.join(OUTDIR, f"{ticker.lower()}.txt")
    with open(outpath, "w") as f:
        for date, row in df.iterrows():
            # Write date then four price samples: open, high, low, close
            # Students compute high/low/avg from these four values
            date_str = date.strftime("%Y-%m-%d")
            line = f"{date_str}\n{float(row['Open']):.2f} {float(row['High']):.2f} {float(row['Low']):.2f} {float(row['Close']):.2f}\n"
            f.write(line)

    print(f"  Wrote {len(df)} days to {outpath}")

print("\nDone. Files are in ./" + OUTDIR)