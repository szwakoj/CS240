// Your code here
// Implement stock_array.h
// Do not include anything other than "stock_array.h", it has what you need

#include "stock_array.h"

StockArray sa_create(size_t initial_capacity)
{
	// TODO
	return NULL;
}

void sa_destroy(StockArray* sa)
{
	// TODO
}

void sa_append(StockArray* sa, DayRecord record)
{
	// TODO
}

DayRecord sa_get(StockArray* sa, size_t index)
{
	// TODO
	return NULL;
}

int sa_load_data(StockArray* sa, const char* filename)
{
	// TODO
	return NULL;
}

double sa_overall_high(StockArray* sa)
{
	// TODO
	return 0.0;
}

double sa_overall_low(StockArray* sa)
{
	// TODO
	return 0.0;
}

double sa_overall_avg(StockArray* sa)
{
	// TODO
	return 0.0;
}

double* sa_extract_highs(StockArray* sa)
{
	// TODO
	return NULL;
}

double* sa_extract_lows(StockArray* sa)
{
	// TODO
	return NULL;
}

double* sa_extract_avgs(StockArray* sa)
{
	// TODO
	return NULL;
}
/* =========================================================================
 * PLOT SERIES IMPLEMENTATION — DO NOT MODIFY
 * ========================================================================= */

#define PLOT_HEIGHT 20
#define PLOT_WIDTH  60

void plot_series(double* values, size_t n, const char* label)
{
	double min = values[0];
	double max = values[0];
	for (size_t i = 1; i < n; i++) {
		if (values[i] < min) min = values[i];
		if (values[i] > max) max = values[i];
	}

	double range = max - min;
	if (range == 0.0) range = 1.0;

	char grid[PLOT_HEIGHT][PLOT_WIDTH + 1];
	for (int r = 0; r < PLOT_HEIGHT; r++) {
		memset(grid[r], ' ', PLOT_WIDTH);
		grid[r][PLOT_WIDTH] = '\0';
	}

	for (int col = 0; col < PLOT_WIDTH; col++) {
	size_t idx = (size_t)((double)col / PLOT_WIDTH * n);
	if (idx >= n) idx = n - 1;
	int row = (int)((values[idx] - min) / range * (PLOT_HEIGHT - 1));
	row = (PLOT_HEIGHT - 1) - row;
	grid[row][col] = '*';
	}

	printf("\n  %s\n", label);
	for (int r = 0; r < PLOT_HEIGHT; r++) {
		if (r % 5 == 0) {
			double price = max - ((double)r / (PLOT_HEIGHT - 1)) * range;
			printf("%8.2f |%s\n", price, grid[r]);
		} else {
			printf("         |%s\n", grid[r]);
		}
	}

	printf("         +");
	for (int i = 0; i < PLOT_WIDTH; i++) printf("-");
	printf("\n");
	printf("         0");
	for (int i = 0; i < PLOT_WIDTH - 12; i++) printf(" ");
	printf("day %zu\n", n - 1);
}