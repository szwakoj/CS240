/*
 * stock_array.h
 *
 * A dynamic array of DayRecord structs for storing and analyzing
 * daily stock price data loaded from a CSV file.
 */

#ifndef STOCK_ARRAY_H
#define STOCK_ARRAY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_CAPACITY	8		// Starting capacity of the dynamic array
#define DATE_LEN			12		// Max length of a date string "YYYY-MM-DD"
#define LINE_BUF			256		// Max length of a single CSV line


typedef struct {
    char	date[DATE_LEN];  // Date string, e.g. "2024-01-02"
    double	high;            // Highest price sample seen for this day
    double	low;             // Lowest price sample seen for this day
    double	avg;             // Average of all price samples for this day
} DayRecord;

typedef struct {
    DayRecord*	records;     // Heap-allocated array of DayRecord structs
    size_t		size;        // Number of records currently stored
    size_t		capacity;    // Total number of records that can be stored
} StockArray;


StockArray sa_create(size_t initial_capacity);
void sa_destroy(StockArray* sa);

void sa_append(StockArray* sa, DayRecord record);

DayRecord sa_get(StockArray* sa, size_t index);

int sa_load_data(StockArray* sa, const char* filename);

double sa_overall_high(StockArray* sa);
double sa_overall_low(StockArray* sa);
double sa_overall_avg(StockArray* sa);

double* sa_extract_highs(StockArray* sa);
double* sa_extract_lows(StockArray* sa);
double* sa_extract_avgs(StockArray* sa);


void plot_series(double* values, size_t n, const char* label);

#endif /* STOCK_ARRAY_H */