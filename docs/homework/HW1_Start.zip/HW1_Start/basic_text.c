#include <stdio.h>
#include <string.h>

// Defining max string sizes
#define MAX_FNAME 100
#define MAX_DESC 1000

// Storing file locations
const char* rooms_filename = "room_files/rooms.txt";
const char* conns_filename = "room_files/connections.txt";

// Because of how strings are read from files, I have provided a helper function
// that will take care of trailing newlines and replace it with the NULL terminator
void remove_newline(char* str);

int main()
{	
	// File pointer for opening rooms.txt and find all other rooms
	FILE* rooms_file = fopen(rooms_filename, "r");

	// Get the number of rooms from the top of rooms.txt
	int num_rooms;
	fscanf(rooms_file, "%d", &num_rooms);
	// Consume the newline after the number
	fgetc(rooms_file); 

	// Temporary text buffer to store file names from rooms.txt
	char fname_buffer[MAX_FNAME];
	// Temporary text buffer to read information from the indivdual room files
	char buffer[MAX_DESC];

	// Separate file pointer for each room file
	FILE* cur_room_file;

	for(int i = 0; i < num_rooms; i++){
		// Gets the next string in the rooms.txt file
		fgets(fname_buffer, MAX_FNAME, rooms_file);
		remove_newline(fname_buffer);

		printf("Room %d\nFilename: %s\n", i, fname_buffer);

		cur_room_file = fopen(fname_buffer, "r");

		// Get room name and print
		fgets(buffer, MAX_DESC, cur_room_file);
		remove_newline(buffer);
		printf("Room Name: %s\n", buffer);

		// Get room description and print
		fgets(buffer, MAX_DESC, cur_room_file);
		remove_newline(buffer);
		printf("Room Description: %s\n", buffer);

		// Visual separator
		printf("===================\n");

		fclose(cur_room_file);
	}

	fclose(rooms_file);
	
	return 0;
}

void remove_newline(char* str)
{
    int len = strlen(str);
    if (len > 0 && str[len - 1] == '\n') {
        str[len - 1] = '\0';
    }
}