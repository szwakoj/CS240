#pragma once

#include <vector>
#include <cstdint>

// FNV-1a constants - defined in hashes.cpp
extern const uint64_t FNV_OFFSET_BASIS;
extern const uint64_t FNV_PRIME;

// Hashing algorithms - all take raw binary file contents
// and return an index in range [0, tableSize)
int summation_hash	(const std::vector<uint8_t>& bytes, int tableSize);
int polynomial_hash	(const std::vector<uint8_t>& bytes, int tableSize, int p);
int djb2_hash		(const std::vector<uint8_t>& bytes, int tableSize);
int fnv1a_hash		(const std::vector<uint8_t>& bytes, int tableSize);