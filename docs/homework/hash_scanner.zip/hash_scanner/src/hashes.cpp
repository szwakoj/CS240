#include "hashes.h"

// YOU DO THIS FILE

// FNV Constants
const uint64_t FNV_OFFSET_BASIS = 14695981039346656037ULL;
const uint64_t FNV_PRIME        = 1099511628211ULL;


//  SUMMATION HASH
int summation_hash(const std::vector<uint8_t>& bytes, int tableSize)
{
	// TODO: Implement summation hash

	uint64_t sum = 0;

	for(const auto& byte : bytes) {
		sum += byte;
	}

	return sum % tableSize;
}

//  POLYNOMIAL ROLLING HASH
int polynomial_hash(const std::vector<uint8_t>& bytes, int tableSize, int p = 31)
{
	// TODO: Implement polynomial rolling hash

	return -1;
}

//  djb2
int djb2_hash(const std::vector<uint8_t>& bytes, int tableSize)
{
	// TODO: Implement djb2

	return -1;
}

//  FNV-1a (Fowler-Noll-Vo)

int fnv1a_hash(const std::vector<uint8_t>& bytes, int tableSize)
{
	// TODO: Implement FNV-1a

	return -1;
}