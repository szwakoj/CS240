// Made using Claude
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <cmath>
#include "../include/hashes.h"

// ============================================================
//  UTILITIES
// ============================================================

// Convert a string to bytes for easy test input
std::vector<uint8_t> toBytes(const std::string& s) {
    return std::vector<uint8_t>(s.begin(), s.end());
}

// Simple pass/fail tracker
int passed = 0;
int failed = 0;

void report(const std::string& testName, bool result) {
    if (result) {
        std::cout << "  [PASS] " << testName << std::endl;
        passed++;
    } else {
        std::cout << "  [FAIL] " << testName << std::endl;
        failed++;
    }
}

// ============================================================
//  SECTION 1: CORRECTNESS TESTS
//  These must all pass before analysis means anything.
//  A hash that fails correctness is broken, not just bad.
// ============================================================

void testDeterminism() {
    std::cout << "\n--- Determinism ---" << std::endl;
    std::cout << "Same input must always produce the same output.\n" << std::endl;

    std::vector<uint8_t> bytes = toBytes("hello");
    int tableSize = 101;

    report("summation:  same input twice",  summation_hash(bytes, tableSize) == summation_hash(bytes, tableSize));
    report("polynomial: same input twice",  polynomial_hash(bytes, tableSize, 31) == polynomial_hash(bytes, tableSize, 31));
    report("djb2:       same input twice",  djb2_hash(bytes, tableSize) == djb2_hash(bytes, tableSize));
    report("fnv1a:      same input twice",  fnv1a_hash(bytes, tableSize) == fnv1a_hash(bytes, tableSize));
}

void testBounds() {
    std::cout << "\n--- Bounds ---" << std::endl;
    std::cout << "Output must always be in [0, tableSize).\n" << std::endl;

    // Test across a few different table sizes and inputs
    std::vector<std::vector<uint8_t>> inputs = {
        toBytes("hello"),
        toBytes("a"),
        toBytes("the quick brown fox"),
        {0x00},                          // null byte
        {0xFF, 0xFF, 0xFF, 0xFF},        // all max bytes
        {0x4D, 0x5A, 0x90, 0x00}         // MZ header (exe-like)
    };

    std::vector<int> tableSizes = {7, 101, 1009};

    bool summationOk  = true;
    bool polynomialOk = true;
    bool djb2Ok       = true;
    bool fnv1aOk      = true;

    for (int tableSize : tableSizes) {
        for (const std::vector<uint8_t>& input : inputs) {
            int s = summation_hash(input, tableSize);
            int p = polynomial_hash(input, tableSize, 31);
            int d = djb2_hash(input, tableSize);
            int f = fnv1a_hash(input, tableSize);

            if (s < 0 || s >= tableSize) summationOk  = false;
            if (p < 0 || p >= tableSize) polynomialOk = false;
            if (d < 0 || d >= tableSize) djb2Ok       = false;
            if (f < 0 || f >= tableSize) fnv1aOk      = false;
        }
    }

    report("summation:  always in [0, tableSize)",  summationOk);
    report("polynomial: always in [0, tableSize)",  polynomialOk);
    report("djb2:       always in [0, tableSize)",  djb2Ok);
    report("fnv1a:      always in [0, tableSize)",  fnv1aOk);
}

void testKnownValues() {
    std::cout << "\n--- Known Values ---" << std::endl;
    std::cout << "Verify output matches hand-calculated expected values.\n" << std::endl;

    // Hand calculated:
    // "abc" bytes = [97, 98, 99], sum = 294, 294 % 101 = 92
    report("summation:  'abc' % 101 == 92",
        summation_hash(toBytes("abc"), 101) == 92);

    // djb2 "abc":
    // hash = 5381
    // hash = 5381 * 33 + 97  = 177572
    // hash = 177572 * 33 + 98 = 5859974
    // hash = 5859974 * 33 + 99 = 193379121
    // 193379121 % 101 = 2
    report("djb2:       'abc' % 101 == 2",
        djb2_hash(toBytes("abc"), 101) == 2);

    // FNV-1a "abc":
    // Start: 14695981039346656037
    // XOR 97, multiply by FNV_PRIME -> ...
    // XOR 98, multiply               -> ...
    // XOR 99, multiply               -> 1335831723
    // 1335831723 % 101 = 88
    report("fnv1a:      'abc' % 101 == 88",
        fnv1a_hash(toBytes("abc"), 101) == 88);
}

void testOrderSensitivity() {
    std::cout << "\n--- Order Sensitivity ---" << std::endl;
    std::cout << "Positional algorithms must treat 'ab' != 'ba'." << std::endl;
    std::cout << "Summation WILL collide here — that is expected and correct.\n" << std::endl;

    std::vector<uint8_t> ab = toBytes("ab");
    std::vector<uint8_t> ba = toBytes("ba");
    int tableSize = 1009;

    // Summation should collide — same bytes, same sum
    report("summation:  'ab' == 'ba' (expected collision)",
        summation_hash(ab, tableSize) == summation_hash(ba, tableSize));

    // These should NOT collide
    report("polynomial: 'ab' != 'ba'",
        polynomial_hash(ab, tableSize, 31) != polynomial_hash(ba, tableSize, 31));
    report("djb2:       'ab' != 'ba'",
        djb2_hash(ab, tableSize) != djb2_hash(ba, tableSize));
    report("fnv1a:      'ab' != 'ba'",
        fnv1a_hash(ab, tableSize) != fnv1a_hash(ba, tableSize));
}

// ============================================================
//  SECTION 2: ANALYSIS TESTS
//  Only meaningful if correctness tests pass.
//  These are not pass/fail — they print data for you to read
//  and answer questions about in the written portion.
// ============================================================

struct HashStats {
    int   collisions;
    int   maxChainLength;
    double avgChainLength;
    double loadFactor;
};

HashStats analyzeDistribution(
    const std::vector<std::vector<uint8_t>>& inputs,
    int (*hashFn)(const std::vector<uint8_t>&, int),
    int tableSize)
{
    std::map<int, int> buckets;

    for (const std::vector<uint8_t>& input : inputs) {
        buckets[hashFn(input, tableSize)]++;
    }

    int collisions    = 0;
    int maxChain      = 0;
    int occupiedBuckets = 0;
    int totalChain    = 0;

    for (const std::pair<const int, int>& bucket : buckets) {
        int count = bucket.second;
        if (count > 1) collisions += count - 1;
        if (count > maxChain) maxChain = count;
        occupiedBuckets++;
        totalChain += count;
    }

    HashStats stats;
    stats.collisions     = collisions;
    stats.maxChainLength = maxChain;
    stats.avgChainLength = occupiedBuckets > 0
                            ? (double)totalChain / occupiedBuckets
                            : 0.0;
    stats.loadFactor     = (double)inputs.size() / tableSize;

    return stats;
}

void printStats(const std::string& name, const HashStats& stats) {
    std::cout << "  " << name << std::endl;
    std::cout << "    Collisions:       " << stats.collisions     << std::endl;
    std::cout << "    Max chain length: " << stats.maxChainLength << std::endl;
    std::cout << "    Avg chain length: " << stats.avgChainLength << std::endl;
    std::cout << "    Load factor:      " << stats.loadFactor     << std::endl;
}

void testCollisionAnalysis() {
    std::cout << "\n--- Collision Analysis ---" << std::endl;
    std::cout << "Distribution quality across 100 generated inputs." << std::endl;
    std::cout << "Lower collisions and shorter chains = better hash.\n" << std::endl;

    // Generate 100 varied byte sequences simulating small files
    std::vector<std::vector<uint8_t>> inputs;
    for (int i = 0; i < 100; i++) {
        std::vector<uint8_t> bytes;
        // MZ header
        bytes.push_back(0x4D);
        bytes.push_back(0x5A);
        // Varied body based on i
        for (int j = 0; j < 10; j++) {
            bytes.push_back(static_cast<uint8_t>((i * 7 + j * 13) % 256));
        }
        inputs.push_back(bytes);
    }

    int tableSize = 101; // intentionally small to stress test distribution

	auto poly_fn = [](const std::vector<uint8_t>& b, int t) {
		return polynomial_hash(b, t, 31);
	};
    printStats("summation",  analyzeDistribution(inputs, summation_hash,  tableSize));
    printStats("polynomial", analyzeDistribution(inputs, poly_fn, tableSize));
    printStats("djb2",       analyzeDistribution(inputs, djb2_hash,       tableSize));
    printStats("fnv1a",      analyzeDistribution(inputs, fnv1a_hash,      tableSize));
}

void testScaling() {
    std::cout << "\n--- Scaling ---" << std::endl;
    std::cout << "How does collision count change as table size grows?" << std::endl;
    std::cout << "Using 200 inputs across three table sizes.\n" << std::endl;

    std::vector<std::vector<uint8_t>> inputs;
    for (int i = 0; i < 200; i++) {
        std::vector<uint8_t> bytes;
        bytes.push_back(0x4D);
        bytes.push_back(0x5A);
        for (int j = 0; j < 8; j++) {
            bytes.push_back(static_cast<uint8_t>((i + j * 17) % 256));
        }
        inputs.push_back(bytes);
    }

    std::vector<int> tableSizes = {101, 1009, 10007};

    for (int tableSize : tableSizes) {
        std::cout << "\n  Table size: " << tableSize << std::endl;
        printStats("  summation",  analyzeDistribution(inputs, summation_hash,  tableSize));
        printStats("  djb2",       analyzeDistribution(inputs, djb2_hash,       tableSize));
        printStats("  fnv1a",      analyzeDistribution(inputs, fnv1a_hash,      tableSize));
    }
}

// ============================================================
//  MAIN
// ============================================================

int main() {
    std::cout << "========================================" << std::endl;
    std::cout << "         HASH FUNCTION TEST SUITE       " << std::endl;
    std::cout << "========================================" << std::endl;

    // -- SECTION 1: CORRECTNESS --
    // All of these must pass before analysis results are meaningful
    std::cout << "\n==== SECTION 1: CORRECTNESS ====" << std::endl;
    testDeterminism();
    testBounds();
    testKnownValues();
    testOrderSensitivity();

    std::cout << "\n----------------------------------------" << std::endl;
    std::cout << "Correctness: " << passed << " passed, " << failed << " failed" << std::endl;
    std::cout << "----------------------------------------" << std::endl;

    if (failed > 0) {
        std::cout << "\nFix correctness failures before reading analysis." << std::endl;
        std::cout << "Analysis results are meaningless if the hash is broken.\n" << std::endl;
    }

    // -- SECTION 2: ANALYSIS --
    std::cout << "\n==== SECTION 2: ANALYSIS ====" << std::endl;
    std::cout << "These are not pass/fail. Read the output and answer" << std::endl;
    std::cout << "the written questions in the homework submission.\n"  << std::endl;
    testCollisionAnalysis();
    testScaling();

    std::cout << "\n========================================" << std::endl;
    std::cout << "              DONE                      " << std::endl;
    std::cout << "========================================\n" << std::endl;

    return failed > 0 ? 1 : 0;
}