#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <filesystem>

namespace fs = std::filesystem;

int main(int argc, char* argv[])
{
	if (argc != 3) {
		std::cerr << "Usage: hash_scanner ./known/ ./target/" << std::endl;
		return 1;
	}

	std::string known_path	= argv[1];
	std::string target_path = argv[2];

	// Validate both directories exist
	if (!fs::exists(known_path) || !fs::is_directory(known_path)) {
		std::cerr << "Error: known folder not found: " << known_path << std::endl;
		return 1;
	}
	if (!fs::exists(target_path) || !fs::is_directory(target_path)) {
		std::cerr << "Error: target folder not found: " << target_path << std::endl;
		return 1;
	}

	std::cout << "Starting hash_scanner..." << std::endl;

	// Collect all files in target directory
	std::vector<fs::path> target_files;
	for (const auto& entry : fs::directory_iterator(target_path)) {
		if (entry.is_regular_file()) {
			target_files.push_back(entry.path());
		}
	}

	std::cout << "hash_scanner found " << target_files.size() << " files!" << std::endl;

	// YOU DO THIS
	// TODO: Collect known file names for reference


	std::vector<std::string> malicious_files;

	for (const auto& file : target_files) {
		std::string filename = file.filename().string();
		std::cout << "scanning " << filename << "... ";

		// YOU DO THIS
		// TODO: Hash file contents and look up in knownMap

		bool found = true;

		if (found) {
			std::cout << "FAIL" << std::endl;
			malicious_files.push_back(filename);
		} else {
			std::cout << "PASS" << std::endl;
		}
	}

	// Write results
	std::ofstream outFile("malicious.txt");
	if (!outFile.is_open()) {
		std::cerr << "Error: could not write malicious.txt" << std::endl;
		return 1;
	}

	for (const auto& name : malicious_files) {
		outFile << name << "\n";
	}
	outFile.close();

	if (malicious_files.empty()) {
		std::cout << "No malicious files found." << std::endl;
	} else {
		std::cout << "Found " << malicious_files.size() << " malicious files!" << std::endl;
	}

	std::cout << "Wrote malicious names to malicious.txt." << std::endl;

	return 0;
}